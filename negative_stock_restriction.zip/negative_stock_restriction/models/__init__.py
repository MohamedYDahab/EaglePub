from . import res_config_settings
from . import stock_move
from . import pos_session
from . import pos_config
from . import product_template
from . import product_category
from . import stock_warehouse
from . import sale_order
