{
    'name': 'Sale Price Control',
    'version': '17.0.7.0.0',
    'category': 'Sales',
    'summary': 'Prevent confirming sale orders with prices below cost without password authorization',
    'description': """
Sale Price Control v6 — Pure Server-Side
=========================================
- When user clicks Confirm on a sale order, checks all lines for below-cost pricing.
- If any line has price below cost, opens a password authorization wizard.
- Works with both standard unit price AND packaging price (sale_packaging_extended).
- Only users in "Allow Below Cost Price" group with a configured password can authorize.
- Password field added to user preferences.
- 100% server-side: no JavaScript, no browser cache issues.
    """,
    'author': 'Custom',
    'license': 'LGPL-3',
    'depends': ['sale_management', 'product', 'sale_packaging_extended'],
    'data': [
        'security/security_groups.xml',
        'security/ir.model.access.csv',
        'wizard/price_override_wizard_views.xml',
        'views/res_users_views.xml',
    ],
    'installable': True,
    'application': False,
    'auto_install': False,
}
